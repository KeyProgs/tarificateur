<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Devis extends Model {
   protected $fillable = [
      'id', 'cotisation', 'reduction', 'numero_contrat', 'date_debut', 'date_fin',
      'fiche_etat_id', 'simulation_id', 'mode_id', 'compte_id'
   ];

   protected $dates = [
      'created_at', 'updated_at', 'deleted_at'
   ];

   public function simulation() {
      return $this->belongsTo('App\Simulation', 'simulation_id', 'id');
   }

   public function compte() {
      return $this->hasOne('App\Compte', 'id', 'compte_id');
   }

}
