<?php

namespace App\Http\Controllers;

use App\Banque;
use App\Civilite;
use App\Equipe;
use App\Fiche;
use App\Profession;
use App\Provenance;
use App\Regime;
use App\Situation_familiale;
use App\User;
use App\User_equipe;
use App\Ville;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class GlobaleController extends Controller {


   public function listeCivilites() {
      return Civilite::all();
   }

   public function listeProfessions() {
      return Profession::all();
   }

   public function listeRegimes() {
      return Regime::all();
   }

   public function listeSituationFamiliales() {
      return Situation_familiale::all();
   }

   public function listeProvenances() {
      return Provenance::all();
   }

   public function listeUsers() {
      return User::all();
   }

   //send success message
   public function sendResponse($result, $message) {
      $response = [
         'success' => true,
         'data' => $result,
         'message' => $message,
      ];
      return response()->json($response, 200);
   }

   //send error message
   public function sendError($error, $errorMessages = [], $code = 404) {
      $response = [
         'success' => false,
         'message' => $error,
      ];
      if(!empty($errorMessages)) {
         $response['data'] = $errorMessages;
      }
      return response()->json($response, $code);
   }

   //for mail
   public function setEnvironmentValue($envKey, $envValue) {
      $envFile = app()->environmentFilePath();
      $str = file_get_contents($envFile);

      $oldValue = strtok($str, "{$envKey}=");

      $str = str_replace("{$envKey}={$oldValue}", "{$envKey}={$envValue}\n", $str);

      $fp = fopen($envFile, 'w');
      fwrite($fp, $str);
      fclose($fp);
   }


   //multi search by value & etat fiche
   public function getFichesIds($etatId = null, $datasearch, $alletat , $rappel = null) {

      //dd($rappel,'zerzer');
      $user = User::findOrFail(Auth::user()->id);
      $usersIds = $user->getUsersEquipeByUser($user->id);
      foreach($datasearch as $key => $value) {
         if($value == null) {
            $datasearch[$key] = "%%";
         } else {
            $datasearch[$key] = "%" . $value . "%";
         }
      }
      $fiches = DB::table('fiches')
         ->join('fiche_etats', 'fiches.etat_id', '=', 'fiche_etats.id')
         ->join('personnes', 'fiches.personne_id', '=', 'personnes.id')
         ->join('details_personnes', 'fiches.personne_id', '=', 'details_personnes.personne_id');
      if(!$user->isRole('admin')) {
         $fiches->whereIn('fiches.user_id', $usersIds);
      }

      if($alletat == 'false') {
         $fiches->where('fiches.etat_id', '=', $etatId);
        // dd('ok');
      }else //dd('oook');
      $fiches->where(function($query) use ($datasearch) {
         $query->orWhere('fiche_etats.valeur', 'like', $datasearch['etat'])
            ->orWhere('personnes.nom', 'like', $datasearch['nom'])
            ->orWhere('personnes.prenom', 'like', $datasearch['prenom'])
            ->orWhere('details_personnes.telephone_1', 'like', $datasearch['telephone'])
            ->orWhere('details_personnes.email', 'like', $datasearch['email'])
            ->orWhere('details_personnes.adresse', 'like', $datasearch['adresse']);
      });

      if($rappel != null) {
         switch($rappel) {
            case -1:
               $fiches->whereDate('fiches.date_rappel', '<', \Carbon\Carbon::now());
               break;
            case 0:
               $fiches->whereDate('fiches.date_rappel', '=', \Carbon\Carbon::now());
               break;
            case 1:
               $fiches->whereDate('fiches.date_rappel', '>', \Carbon\Carbon::now());
               break;
         }
      }

      $fiches = $fiches->pluck('fiches.id');
      return $fiches;


      /*$fiches = DB::table('fiches')
      ->join('fiche_etats', 'fiches.etat_id', '=', 'fiche_etats.id')
      ->join('personnes', 'fiches.personne_id', '=', 'personnes.id')
      ->join('details_personnes', 'fiches.personne_id', '=', 'details_personnes.id')
      ->where('fiches.user_id', '=', $user_id)
      ->where('fiche_etats.valeur', 'like', $datasearch['etat'])
      ->orWhere('personnes.nom', 'like', $datasearch['nom'])
      ->orWhere('personnes.prenom', 'like', $datasearch['prenom'])
      ->orWhere('details_personnes.telephone_1', 'like', $datasearch['telephone'])
      ->orWhere('details_personnes.email', 'like', $datasearch['email'])
      ->orWhere('details_personnes.adresse', 'like', $datasearch['adresse'])
      ->pluck('fiches.id');*/

      /*$query = "select P.id as IDPersonne, F.id, FE.valeur as ETAT from fiches F,fiche_etats FE, personnes P, details_personnes DP
                            WHERE FE.id=F.etat_id
                            and F.personne_id=P.id
                            and F.user_id=3
                            and P.id=DP.id

                            and FE.valeur like '%De%'
                            and P.nom like '%De%'
                            and P.prenom like '%De%'
                            and DP.email like '%De%'
                            and DP.adresse like '%De%'
                            ";*/

      /* ->where('fiche_etats.valeur', 'like', $datasearch['etat'])
       ->orWhere('personnes.nom', 'like', $datasearch['nom'])
       ->orWhere('personnes.prenom', 'like', $datasearch['prenom'])
       ->orWhere('details_personnes.telephone_1', 'like', $datasearch['telephone'])
       ->orWhere('details_personnes.email', 'like', $datasearch['email'])
       ->orWhere('details_personnes.adresse', 'like', $datasearch['adresse'])
       */


   }


   public function getVilles($code_postale = null) {
      $response = '';
      if($code_postale === null) {
         $villes = Ville::All();
      } else {
         $villes = Ville::where('zip_code', 'like', $code_postale . '%')
            ->get();
      }
      foreach($villes as $ville) {
         $response .= '<option value="' . $ville->id . '">' . $ville->name . '</option>';
      }
      return $this->sendResponse($response, '');
   }

   public function getBanques(Request $request) {
      $response = '';
      if($request->nom_banque === null) {
         $banques = Banque::All();
      } else {
         $banques = Banque::where('nom', 'like', '%' . $request->nom_banque . '%')
            ->get();
      }
      //dd($banques);
      foreach($banques as $banque) {
         if($banque->ville->name != null) {
            $response .= '<a  class="pointer banque-name" data-banque-nom ="' . $banque->nom . '" data-banque-adresse ="' . $banque->adresse . '" data-ville-id ="' . $banque->ville_id . '"  data-ville-nom ="' . $banque->ville->name . '" >' . ucfirst($banque->nom) . '</a><br>';

         }
      }
      return $this->sendResponse($response, '');
   }


}
