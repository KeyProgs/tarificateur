<?php

namespace App\Http\Controllers;


use App\Departement;
use App\Departement_regles;
use App\Departement_zones;
use App\Details_personne;
use App\Fiche;
use App\Formule;
use App\Gamme;
use App\Personne;
use App\Personne_personne;
use App\Prix_formule;
use App\Regime;
use App\Regime_regles;
use App\Regle;
use App\Ville;
use App\Zone;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TarificateurController extends GlobaleController
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }

    /**
     *
     */
    public function Tarificateur($ficheId = null, $formule_id = null)
    {
        $PrixFormuleFiche = 0;
        $Cotisation = null;
        $fiche = Fiche::find($ficheId);
        $Formule = Formule::find($formule_id);
        $formule_id = $formule_id;

        if ($fiche != null && $Formule != null) {
            // dd('ook');
            $Gamme = Gamme::findOrFail($Formule->gamme_id);
            $departement_id = substr($fiche->personne->details->ville_id, -1, 2);
            $cp = $fiche->personne->details->code_postal;
            $ville = new Ville();
            $departement_id = $ville->getCodeDepFromCP($cp);
            $regime_id = $fiche->personne->regime_id;
            //$Formule = new Formule();
            $validate = "validate" . $Gamme->id;
            $data = [
                'nbEnfants' => 0,
                'AgeEnfant' => null,
                'formule_id' => $formule_id,
                'departement_id' => $departement_id,
                'regime_idP' => null,
                'regime_idC' => null,
                'conjoint' => false,
                'cotisation' => 0,
                'valide' => false,

            ];
            $ages[] = $fiche->personne;
            $data['regime_idP'] = $fiche->personne->regime_id;
            if (!is_null($fiche->personne->conjoint())) {
                $ages[] = $fiche->personne->conjoint();
                $data['conjoint'] = true;
                $data['regime_idC'] = $fiche->personne->conjoint()->regime_id;
            }
            if (!empty($fiche->personne->enfants())) {
                foreach ($fiche->personne->enfants() as $Enfant) {
                    $ages[] = $Enfant;
                    $data['nbEnfants'] = sizeof($fiche->personne->enfants());
                }
            }

            foreach ($ages as $age) {
                $Personne = $age;
                $age = Carbon::parse($age->date_naissance)->diff(\Carbon\Carbon::now())->format('%y');


                if ($Gamme->TchequeAge($age)) {
                    $agecalcule = $age;

                    $query = "select pf.prix from  prix_formules pf, regles r , regime_regles rr , formules f ,departement_zones dz, zones z, departements d
                    where pf.regle_id=r.id 
                    and dz.zone_id=z.id
                    and z.id=r.zone_id
                    and rr.regle_id=r.id
                    and r.formule_id=f.id
                    and r.formule_id=$formule_id
                    and rr.regime_id=$Personne->regime_id
                    and dz.departement_id=d.id
                    and d.code=$departement_id 
                    and pf.age=$age";
                    $Prix = DB::select($query);
                    if (sizeof($Prix) > 0) {
                        //dd($Prix);
                        //$Gamme = DB::table('gammes')->join('formules', 'formules.', '', '');
                        //echo "Cotisation:" . (double)$Prix[0]->prix . "<br>";
                        //echo "<br> age: $age prix: " . (double)$Prix[0]->prix . '<br>';
                        $data['cotisation'] = $data['cotisation'] + (double)$Prix[0]->prix;
                        //dd($data);
                    } else {
                        //dd($data);
                        if ($Gamme->e_age > 0) {
                            $query = "select pf.prix from  prix_formules pf, regles r , regime_regles rr , formules f ,departement_zones dz, zones z, departements d
                    where pf.regle_id=r.id 
                    and dz.zone_id=z.id
                    and z.id=r.zone_id
                    and rr.regle_id=r.id
                    and r.formule_id=f.id
                    and r.formule_id=$formule_id
                    and rr.regime_id=$regime_id 
                    and dz.departement_id=d.id
                    and d.code=$departement_id  
                    and pf.age=" . $Gamme->min_age;
                            // dd($data);
                            $Prix = DB::select($query);
                            //dd($Prix);
                            if (sizeof($Prix) > 0) {
                                $data['cotisation'] = $data['cotisation'] + (double)$Prix[0]->prix;
                                // echo "<br> age:" . Gamme::findOrFail(Formule::findOrFail($formule_id)->gamme_id)->min_age . " prix: " . (double)$Prix[0]->prix . '<br>';
                            } else {
                                //echo "prix introuvable pour age:$age formule: $formule_id Regime:$regime_id departement:$departement_id <br>";
                                return $this->sendResponse('Prix enfant Non saisie', '');
                            }

                        } else {
                            return $this->sendResponse('Age enfant non Elligible', '');
                        }
                        //echo "prix  introuvable pour $age <br> ==> " . (double)$Prix[0]->prix;
                    }
                } else {
                    return $this->sendResponse("Age $age Non Elligible", '');

                }
            }

            return $this->sendResponse((double)$data['cotisation'], '');
        } else {
            return $this->sendResponse('Err Fiche ou formule Introuvable', '');
        }


        //return $Formule->$validate($Prix[0]->prix);

        //return $this->$validate
    }


    public function getPrices(Request $request, $formule_id = null, $ficheId = null)
    {

        return $this->Tarificateur($request['data']['IdFiche'], $request['data']['IdFormule']);
    }

    function GetGAmmePrices($gamme_id)
    {
        $Formules = Formule::where('gamme_id', '=', gamme_id)->get;
        foreach ($Formules as $formule) {
            $this->getPrices($formule->id);
        }
    }

    function regle($gamme_id, $zone_id = null)
    {

        $Gamme = Gamme::FindOrFail($gamme_id);
        $Departements = Departement::all();
        $Regimes = Regime::all();
        $Departement_zones = DB::table('departements')
            ->join('departement_zones', 'departement_zones.departement_id', '=', 'departements.id')
            ->whereNull('.departement_zones.deleted_at')
            ->where('.departement_zones.zone_id', '=', $zone_id)->get();
        $Formules = Formule::where('gamme_id', '=', $gamme_id)->get();
        //dd($Departement_zones);

        foreach ($Formules as $formule) {
            $prix_s = DB::table('prix_formules')
                ->join('regles', 'prix_formules.regle_id', '=', 'regles.id')
                ->join('zones', 'zones.id', '=', 'regles.zone_id')
                ->where('zones.id', $zone_id)
                ->where('regles.formule_id', $formule->id)
                ->select('prix', 'age','regles.id as idregles','zones.id as zone_id')->get();;

            //dd($prix_s);
            $idregles=$prix_s[0]->idregles;
            $zone_id=$prix_s[0]->zone_id;
            if (!empty($prix_s)) {

                foreach ($prix_s as $prix_) {
                    $array[$prix_->age] = $prix_->prix;
                }
            }
            $formule->prix = $array;
            //dd($formule->prix);
        }
        //dd( $formule->prix);


        return view('regles', compact('Gamme','zone_id','idregles', 'Departements', 'Regimes', 'Departement_zones', 'Formules'));

    }


    function regles(Request $request)
    {
        //test TEXTAREA \r\n
        //$F6 = $request->F6;
        //$F6=explode("\r\n",$F6);
        //print_r($F6) ;
        //exit;
        $Departement_zones = explode("\n", $request->Departement_regles);
        $Regime_regles = $request->Regime_regles;
        //dd($Regime_regles);

        //dd($Regime_regles);
        $FormulesIds[] = null;
        $gamme_id = $request->gamme_id;
        $ZoneName = $request->ZoneName;
        $Annee = $request->annee;
        $Regle_Id = $request->idregles;
        //dd($request->all());


        $Gamme = Gamme::FindOrFail($gamme_id);
        //dd($Gamme);
        $FormulesIds = Formule::where('gamme_id', '=', $gamme_id)->pluck('id');
        //dd($FormulesIds);


        DB::beginTransaction();
        $zone_id=$request->zone_id;
        $zone = Zone::find($zone_id);
        $zone_id = null;
        if ($zone != null) {
            $zone_id = $zone->id;
        } else {
            $zone_id = Zone::create(['gamme_id' => $gamme_id, 'zone' => $ZoneName])->id;
            echo "<br>    $zone_id zone_id created     <br>";
        }



        Departement_zones::where(['zone_id' => $zone_id])->delete();
        echo "<br> === delete all Departement_zones in zone_id $zone_id ";
        foreach ($Departement_zones as $Departement_zone) {

            $Departement_zone = str_replace("\r", "", $Departement_zone);
            if (strlen($Departement_zone) == 1) {
                $Departement_zone = '0' . $Departement_zone;
            }
            $DepId = Departement::where('code', '=', $Departement_zone)->first();

            if ($DepId != null) {
                $DepId = $DepId->id;
                echo "<br> ======> zone_id($zone_id) ===== $Departement_zone trouver sur ID DEP :  DepId($DepId)";
                Departement_zones::create(['zone_id' => $zone_id, 'departement_id' => $DepId]);

            } else {
                echo "ID Departement introuvable avec le code :" . $Departement_zone;
            }
        }

        foreach ($FormulesIds as $FormulesId) {
            $Regle_Id = null;
            $Regle = Regle::where('formule_id', $FormulesId)
                ->where('annee', $Annee)
                ->where('zone_id', $zone_id)
                ->first();

            if ($Regle != null) {
                $Regle_Id = $Regle->id;
                echo " Une regle pour formule_id " . $Regle->id . " existe deja";
            } else {

                $Regle_Id = Regle::create(['formule_id' => $FormulesId, 'annee' => $Annee, 'zone_id' => $zone_id])->id;
                echo "Regle_Id : $Regle_Id (inserted) Zone$zone_id <br>";

            }


            //Table Prix_Formule
            for ($Age = $Gamme->min_age; $Age <= $Gamme->max_age; $Age++) {
                $InputRegle = 'F' . $FormulesId . "_A" . $Age;
                $Prix = $_POST[$InputRegle];
                $Prix = str_replace(",", ".", $Prix);

                //test Prix Existe
                $Prix_formule = Prix_formule::where(['regle_id' => $Regle_Id, 'age' => $Age])->first();
                if ($Prix_formule != null) {
                    //$Prix_formule = Prix_formule::where(['regle_id' => $Regle_Id, 'age' => $Age]);
                    echo "regle  ($Regle_Id) Trouvé Avec Formule : ($FormulesId)   => Prix $Prix sur id : $Prix_formule->id <bR>";
                    $Prix_formule->prix = $Prix;
                    $Prix_formule->save();


                } else {
                    $IDPF = Prix_formule::create(['regle_id' => $Regle_Id, 'age' => $Age, 'prix' => $Prix])->id;
                    echo "regle : ($Regle_Id) Formule : ($FormulesId)   => Prix $Prix sur id : $IDPF <bR>";

                }

            }


            // exit;


        }//

        //Table Regime_regles
        Regime_regles::where(['regle_id' => $Regle_Id])->delete();
        echo "<br> Regime_regles all delete $Regle_Id";
        foreach ($Regime_regles as $regime_regle) {
            //$DepId = Regime::where("libelle", "=", $regime_regle)->first()->id;
            Regime_regles::create(['regime_id' => $regime_regle, 'regle_id' => $Regle_Id]);
            echo "<br> Regime_regles Created";
        }

        DB::commit();
        try {
        } catch (\Exception $e) {
            DB::rollback();
            echo $e->getMessage();
        }
        echo "FIN";
        exit;


    }

}
