<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mode_paiement extends Model
{
    //
}
