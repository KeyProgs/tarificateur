<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Gamme extends Model {
   protected $fillable = [
      'id', 'nom', 'description', 'compagnie_id', 'type_assurance_id', 'e_age', 'e_age2', 'annee', 'min_age', 'max_age'
   ];
   protected $dates = [
      'created_at', 'updated_at', 'deleted_at',
   ];

   public function compagnie() {
      return $this->belongsTo('App\Compagnie', 'compagnie_id', 'id');
   }

   public function formules() {
      return $this->hasMany('App\Formule', 'gamme_id', 'id');
   }

   public function type_assurance() {
      return $this->hasOne('App\Type_assurance', 'id', 'type_assurance_id');
   }

   public function TchequeAge($age) {
      if($age < $this->min_age and $this->e_age == 0) {
         return false;
      }
      return true;
   }

   public function compagnies($gammesIds) {
      $idsString = "";
      foreach($gammesIds as $gammeId) {
         $idsString .= $gammeId . ",";
      }
      $idsString = rtrim($idsString, ",");
      //dd('select distinct g.compagnie_id, c.nom from gammes g , compagnies c where g.compagnie_id = c.id and g.id IN (' . $idsString . ') and c.deleted_at != NULL');
      return DB::select('select distinct g.compagnie_id, c.nom from gammes g , compagnies c where g.compagnie_id = c.id and g.id IN (' . $idsString . ') and c.deleted_at IS NULL');
   }


   public function piece_jointes() {
      return $this->hasMany('App\Piece_jointe', 'gamme_id', 'id');
   }

}
