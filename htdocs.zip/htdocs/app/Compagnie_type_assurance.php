<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Compagnie_type_assurance extends Model
{
    //
}
