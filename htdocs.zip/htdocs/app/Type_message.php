<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Type_message extends Model
{
    //
}
